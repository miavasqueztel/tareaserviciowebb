const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3300;
const DATA_FILE = path.join(__dirname, 'agenda.json');

app.use(express.json());

// Leer los datos desde el archivo
function obtenerAgenda() {
  if (!fs.existsSync(DATA_FILE)) {
    return [];
  }

  const contenido = fs.readFileSync(DATA_FILE, 'utf-8');
  return contenido ? JSON.parse(contenido) : [];
}

// Escribir datos al archivo
function guardarAgenda(contactos) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(contactos, null, 2));
}

// Ruta para obtener todos los contactos
app.get('/agenda', (req, res) => {
  const lista = obtenerAgenda();
  res.status(200).json(lista);
});

// Ruta para agregar un contacto
app.post('/agenda', (req, res) => {
  const { nombre, apellido, telefono } = req.body;

  if (!nombre || !apellido || !telefono) {
    return res.status(422).json({ mensaje: 'Todos los campos son obligatorios' });
  }

  const contactos = obtenerAgenda();
  const nuevo = { nombre, apellido, telefono };

  contactos.push(nuevo);
  guardarAgenda(contactos);

  res.status(201).json({ mensaje: 'Contacto añadido exitosamente', contacto: nuevo });
});

// Iniciar el servidor
app.listen(PORT, () => {
  console.log(`Servidor activo en http://localhost:${PORT}`);
});
